from django.shortcuts import render
from django.http import HttpResponse
import facebook
token="EAADiK5gYER0BAId4rqGoVUQE5uZBCS5zuLgATldI5bfWzoi9MjANvRy4iLlCdQnWWJwa1wucjsn6aiXSVsr2S0r2mLRSxU4ghTZAEgd2IffE1BT7rP9qIUV1tUVYpOiSkR5mCwvIKPTQZCi96V7PhVAWGKjZCqbtJiDhKHSvasoYJAcipptuUIhVpQoFj3TbjhZBkqDqmIwZDZD"

# Create your views here.
def home(request):
    return render(request,'home.html',{'name':'SudhanSakthi'})
def add(request):
    val1=request.POST["con"]
    fb=facebook.GraphAPI(token)
    fb.put_object(parent_object='me', connection_name='feed',
                  message=val1)
    return render(request,'home.html')